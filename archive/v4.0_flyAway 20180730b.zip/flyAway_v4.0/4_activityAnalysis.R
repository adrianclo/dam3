cat("-- analyzing activity parameters\n")

# overall analysis: beam crossings per 30 min / phase -----------------------------------------

activity %>%
    select(-c(time, zt)) %>%
    group_by(day, phase, zt_demi) %>%
    summarise_all(sum) %>% ungroup() -> activity_day

activity_day %>%
    gather(fly_id, activity, -c(day, phase, zt_demi)) %>%
    ggplot(aes(zt_demi, activity)) +
    theme_bw() +
    theme(panel.grid.major = element_blank(),
          panel.grid.minor = element_blank()) +
    geom_rect(mapping = aes(xmin = flyTable$zt_night_onset[aa], xmax = flyTable$zt_night_onset[aa] + flyTable$zt_night_duration[aa] - 1 + .75, ymin = 0, ymax = max(activity)), fill = "gray", alpha = 1/5) +
    geom_point(alpha = 1/10) +
    stat_summary(geom = "point", fun.y = mean, color = "blue") +
    stat_summary(geom = "errorbar", fun.data = mean_se, color = "blue", width = .1) +
    stat_summary(geom = "line", fun.y = mean, color = "blue") +
    labs(x = "ZT", y = "Beam crossings (n)", title = flyTable$import_file[aa]) +
    scale_x_continuous(breaks = seq(0,23,3)) +
    facet_grid(day ~ ., labeller = label_both)
ggsave(paste0(filesDir, subDir, "\\activity_pattern.png"), width = 8.58, height = 3.11)

activity_day %>%
    select(-zt_demi) %>%
    group_by(day, phase) %>%
    summarise_all(sum) %>%
    arrange(phase) %>%
    bind_rows(activity_day %>%
                  select(-c(day, zt_demi)) %>%
                  group_by(phase) %>%
                  summarise_all(sum)) %>%
    ungroup() %>%
    mutate(day = case_when(is.na(day) ~ "TOTAL",
                           TRUE ~ as.character(day))) -> activity_phase

# anticipation indices ------------------------------------------------------------------------

#################################
##  WARNING: NOT FLEXIBLE YET  ##
#################################

## Evening anticipation index = [ (ZT9 to ZT11) - (ZT6 to ZT8) ]  / (ZT6 to ZT11)
## Morning anticipation index = [ (ZT21 to ZT23) - (ZT18 to Z20) ] / (ZT18 to ZT23)
activity %>%
    select(-c(time, zt_demi, phase)) %>%
    filter(between(zt, 6, 11)) %>% # ~ filter(zt >= 6 & zt < 12)
    mutate(period = factor(case_when(between(zt, 6, 8) ~ "pre",
                                     between(zt, 9, 11) ~ "post"), 
                           levels = c("pre", "post"))) %>%
    select(-zt) %>% group_by(day, period) %>% summarise_all(sum) %>%
    select(-period) %>% group_by(day) %>% summarise_all(diff) %>%
    mutate(period = "post_pre_diff") %>% select(day, period, contains("fly")) %>%
    bind_rows(activity %>%
                  select(-c(time, zt_demi, phase)) %>%
                  filter(between(zt, 6, 11)) %>%
                  select(-zt) %>% group_by(day) %>% summarise_all(sum) %>%
                  mutate(period = "sum_activity") %>% select(day, period, contains("fly"))) %>%
    mutate(period = factor(period, levels = c("post_pre_diff", "sum_activity"))) %>%
    arrange(day) -> evening
as.data.frame(select(summarize_all(group_by(evening, day), funs(first)), contains("fly")) / 
                  select(summarize_all(group_by(evening, day), funs(last)), contains("fly"))) %>%
    gather(fly_id, index) %>% mutate(day = rep(paste0("ev_anticip_", 1:3), times = length(flies))) %>%
    spread(day, index) -> evening_anticipation

activity %>%
    select(-c(time, zt_demi, phase)) %>%
    filter(between(zt, 18, 23)) %>%
    mutate(period = factor(case_when(between(zt, 18, 20) ~ "pre",
                                     between(zt, 21, 23) ~ "post"), 
                           levels = c("pre", "post"))) %>%
    select(-zt) %>% group_by(day, period) %>% summarise_all(sum) %>%
    select(-period) %>% group_by(day) %>% summarise_all(diff) %>%
    mutate(period = "post_pre_diff") %>% select(day, period, contains("fly")) %>%
    bind_rows(activity %>%
                  select(-c(time, zt_demi, phase)) %>%
                  filter(between(zt, 18, 23)) %>%
                  select(-zt) %>% group_by(day) %>% summarise_all(sum) %>%
                  mutate(period = "sum_activity") %>% select(day, period, contains("fly"))) %>%
    mutate(period = factor(period, levels = c("post_pre_diff", "sum_activity"))) %>%
    arrange(day) -> morning
as.data.frame(select(summarize_all(group_by(morning, day), funs(first)), contains("fly")) / 
                  select(summarize_all(group_by(morning, day), funs(last)), contains("fly"))) %>%
    gather(fly_id, index) %>% mutate(day = rep(paste0("mo_anticip_", 1:flyTable$experiment_interval[aa]), times = length(flies))) %>%
    spread(day, index) -> morning_anticipation

anticipation <- merge(morning_anticipation, evening_anticipation, by = "fly_id")

# export --------------------------------------------------------

write.table(activity_phase, paste0(filesDir, subDir, "\\activity_phase.txt"), quote = F, sep = "\t", row.names = F)
write.table(activity_day, paste0(filesDir, subDir, "\\activity_pattern.txt"), quote = F, sep = "\t", row.names = F)
# write.table(anticipation, paste0(filesDir, subDir, "\\activity_anticipation.txt"), quote = F, sep = "\t", row.names = F)
rm(list = setdiff(ls(), c("sleep", "activity", "flyTable",
                          "filesDir", "subDir", "aa",
                          # "subsubDir", 
                          # "sleep_day", "boutLength_df",
                          # "nBouts", "aveDurationBouts", "maxDurationBouts", "maxDurationZT", "latency", "ci", "waso", "briefAwake", "briefAwake_koh",
                          # "activity_day", "activity_phase", "anticipation",
                          "flies")))