cat("\n---------------")
cat("\nSLEEP ANALYSIS!")
cat("\n---------------")

cat("\nDATA ANALYSIS STARTED...\n")

## dat_sleep contains the hourly summed sleeping time for each fly per day
## dat_sleep_ave contains the hourly average sleeping time for each fly
dat_sleep =
  dat_false_true %>%
  select(-c(date, hh_mm, phase)) %>%
  group_by(day, zt) %>%
  summarise_all(sum)
dat_sleep = as.data.frame(dat_sleep)

ave_dat_sleep =
  dat_sleep %>% 
  select(-day) %>% 
  group_by(zt) %>% 
  summarise_all(mean)
ave_dat_sleep = as.data.frame(ave_dat_sleep)

## Daytime (ZT0-ZT12) and Nighttime sleep (ZT12-ZT24): SUM over phase PER DAY
dat_sleep_spec =
  dat_sleep %>%
  mutate(phase = rep(c("Day", "Night"), each = 12, times = ZT0_interval)) %>%
  select(-zt) %>%
  group_by(day, phase) %>%
  summarise_all(sum)

# how many sleeping boutons? ------------------------------------
## DAY and NIGHT sleeping boutons + MEAN DURATION per bouton (TOTAL)
total_sleep_boutons_day = numeric()
total_sleep_boutons_day_duration = numeric()
total_sleep_boutons_day_duration_max = numeric()
total_sleep_boutons_night = numeric()
total_sleep_boutons_night_duration = numeric()
total_sleep_boutons_night_duration_max = numeric()

sleep_boutons_length_night_list = list()
sleep_boutons_length_night_df = data_frame(fly = "dummy", bouton_length = 0)

for(ii in 6:dim(dat_false_true)[2]) {
  ## DAY VALUES
  zzz_day = rle(dat_false_true[dat_false_true$phase == "Day", ii])
  total_sleep_boutons_day[ii-5] = sum(zzz_day$values == TRUE)
  total_sleep_boutons_day_duration[ii-5] = round(mean(zzz_day$lengths[zzz_day$values == TRUE]), 2)
  total_sleep_boutons_day_duration_max[ii-5] = max(zzz_day$lengths[zzz_day$values == TRUE])
  
  ## NIGHT VALUES
  zzz_night = rle(dat_false_true[dat_false_true$phase == "Night", ii])
  total_sleep_boutons_night[ii-5] = sum(zzz_night$values == TRUE)
  total_sleep_boutons_night_duration[ii-5] = round(mean(zzz_night$lengths[zzz_night$values == TRUE]), 2)
  total_sleep_boutons_night_duration_max[ii-5] = max(zzz_night$lengths[zzz_night$values == TRUE])
  
  sleep_boutons_length_night_list[[ii-5]] = zzz_night$lengths[zzz_night$values == TRUE]
  names(sleep_boutons_length_night_list)[[ii-5]] = names(dat_false_true)[ii]
}

for(jj in 1:length(sleep_boutons_length_night_list)) {
  temp_df = data_frame(fly = names(sleep_boutons_length_night_list)[[jj]],
                       bouton_length = sleep_boutons_length_night_list[[jj]])
  
  sleep_boutons_length_night_df = bind_rows(sleep_boutons_length_night_df, temp_df)
}
sleep_boutons_length_night_df = filter(sleep_boutons_length_night_df, fly != "dummy")

hist = ggplot(sleep_boutons_length_night_df, aes(bouton_length)) +
  geom_histogram(binwidth = 5) +
  geom_vline(xintercept = median(sleep_boutons_length_night_df$bouton_length), color = "navyblue") +
  annotate("text", x = median(sleep_boutons_length_night_df$bouton_length), y = 0, vjust = 0, label = median(sleep_boutons_length_night_df$bouton_length))
print(hist)

ave_sleep_boutons = data.frame(flyID = paste("fly", 1:flies, sep = "_"),
                               day_boutons = total_sleep_boutons_day, 
                               day_ave_duration = total_sleep_boutons_day_duration, 
                               day_max_duration = total_sleep_boutons_day_duration_max,
                               
                               night_boutons = total_sleep_boutons_night, 
                               night_ave_duration = total_sleep_boutons_night_duration, 
                               night_max_duration = total_sleep_boutons_night_duration_max)

## DAY and NIGHT sleeping boutons + MEAN duration per bouton (per day)
sleep_boutons_day = sleep_boutons_day_duration = sleep_boutons_day_duration_max = data.frame()
sleep_boutons_night = sleep_boutons_night_duration = sleep_boutons_night_duration_max = data.frame()

sleep_boutons_day_duration_max_zt = sleep_boutons_night_duation_max_zt = data.frame()

sleep_latency_day = sleep_latency_night = data.frame()
ci_index_day = ci_index_night = data.frame()
waso_day = waso_night = data.frame()
brief_awake_day = brief_awake_night = data.frame()

for(jj in 1:as.numeric(ZT0_interval)){
  ## subset per day
  temp_file = dat_false_true[dat_false_true$day == jj,]
  for(ii in 6:dim(dat_false_true)[2]) {
    ## subset per day/night phase
    zzz_day = rle(temp_file[temp_file$phase == "Day", ii]); zzz_day = data.frame(values = zzz_day$values, lengths = zzz_day$lengths)
    zzz_day %<>%
      mutate(end = cumsum(lengths),
             start = end - (lengths-1),
             zt_start = floor(start / 60))
    zzz_night = rle(temp_file[temp_file$phase == "Night", ii]); zzz_night = data.frame(values = zzz_night$values, lengths = zzz_night$lengths)
    zzz_night %<>%
      mutate(end = cumsum(lengths),
             start = end - (lengths-1),
             zt_start = floor(start / 60))
    
    sleep_boutons_day[ii-5,jj] = sum(zzz_day$values == TRUE)
    sleep_boutons_day_duration[ii-5,jj] = round(mean(zzz_day$lengths[zzz_day$values == TRUE]), 2)
    sleep_boutons_day_duration_max[ii-5,jj] = max(zzz_day$lengths[zzz_day$values == TRUE])
    sleep_boutons_day_duration_max_zt[ii-5,jj] = zzz_day %>% filter(values == TRUE) %>% filter(lengths == max(lengths)) %>% slice(1) %>% pull(zt_start)
    
    sleep_boutons_night[ii-5,jj] = sum(zzz_night$values == TRUE)
    sleep_boutons_night_duration[ii-5,jj] = round(mean(zzz_night$lengths[zzz_night$values == TRUE]), 2)
    sleep_boutons_night_duration_max[ii-5,jj] = max(zzz_night$lengths[zzz_night$values == TRUE])
    sleep_boutons_night_duration_max_zt[ii-5,jj] = zzz_night %>% filter(values == TRUE) %>% filter(lengths == max(lengths)) %>% slice(1) %>% pull(zt_start)
    
    ## latency to sleep during the day/night (per day)
    # sleep_latency_day[ii-5,jj] = zzz_day[[1]][1] + 1
    # sleep_latency_night[ii-5,jj] = zzz_night[[1]][1] + 1
    if(zzz_day$values[1] == TRUE) {
      sleep_latency_day[ii-5,jj] = 0
    } else sleep_latency_day[ii-5,jj] = zzz_day$lengths[1] + 1
    if(zzz_night$values[1] == TRUE) {
      sleep_latency_night[ii-5,jj] = 0
    } else sleep_latency_night[ii-5,jj] = zzz_night$lengths[1] + 1
    
    ## consolidation_index during the day/night (per day)
    ci_index_day[ii-5,jj] = sum(zzz_day$lengths[zzz_day$values == TRUE]^2) / sum(zzz_day$lengths[zzz_day$values == TRUE])
    ci_index_night[ii-5,jj] = sum(zzz_night$lengths[zzz_night$values == TRUE]^2) / sum(zzz_night$lengths[zzz_night$values == TRUE])
    
    ## wake after sleep onset (WASO)
    waso_day[ii-5,jj] = sum(zzz_day$lengths[zzz_day$values == FALSE][-1])
    waso_night[ii-5,jj] = sum(zzz_night$lengths[zzz_night$values == FALSE][-1])
    
    ## brief awakenings
    brief_awake_day[ii-5,jj] = length(which(zzz_day$lengths[zzz_day$values == FALSE] == 1))
    brief_awake_night[ii-5,jj] = length(which(zzz_night$lengths[zzz_night$values == FALSE] == 1))
  }
}

# when were these sleep boutons? --------------------------------
for(ii in 6:dim(dat_false_true)[2]) {
  lengths = rle(dat_false_true[,ii])$lengths
  values = rle(dat_false_true[,ii])$values
  
  when = data.frame(lengths = lengths, values = values) %>%
    mutate(rowValue = cumsum(lengths) - (lengths - 1))
  head(when)
  ww = when$rowValue
  
  when = mutate(when,
                date = dat_false_true$date[ww],
                hour = dat_false_true$hh_mm[ww])
  head(when)
  when = when %>%
    filter(values == TRUE) %>%
    select(c(rowValue, date, hour, lengths))
  head(when)
  
  write.table(when, paste0("./", subDir, "/sleepBoutons/fly_", ii-5, ".txt"), quote = FALSE, sep = "\t", row.names = FALSE)
}


# output ------------------------------------------------------------------
write.table(dat_sleep, paste0("./", subDir, "/sleep_development.txt"), quote = FALSE, sep = "\t", row.names = FALSE)
write.table(dat_sleep_spec, paste0("./", subDir, "/sleep_cycle.txt"), quote = FALSE, sep = "\t", row.names = FALSE)
write.table(ave_dat_sleep, paste0("./", subDir, "/sleep_pattern.txt"), quote = FALSE, sep = "\t", row.names = FALSE)
write.table(ave_sleep_boutons, paste0(subDir, "/sleep_boutons_summary.txt"), quote = FALSE, sep = "\t", row.names = FALSE)
write.table(sleep_boutons_length_night_df, paste0(subDir, "/sleep_boutons_length_NIGHT.txt"), quote = F, sep = "\t", row.names = F)

graphpad = readline(prompt = "Output in graphpad format (y or n): ")

if(tolower(graphpad) == "y") {
  sleepBoutons = as.data.frame(cbind(1:flies, 
                                     sleep_boutons_day,
                                     sleep_boutons_night))
  aveDuration = as.data.frame(cbind(1:flies, 
                                    sleep_boutons_day_duration,
                                    sleep_boutons_night_duration))
  maxDuration = as.data.frame(cbind(1:flies, 
                                    sleep_boutons_day_duration_max,
                                    sleep_boutons_night_duration_max))
  maxDuration_zt = as.data.frame(cbind(1:flies,
                                       sleep_boutons_day_duration_max_zt,
                                       sleep_boutons_night_duration_max_zt))
  sleepLatency = as.data.frame(cbind(1:flies, 
                                     sleep_latency_day,
                                     sleep_latency_night))
  ciIndex = as.data.frame(cbind(1:flies, 
                                ci_index_day,
                                ci_index_night))
  waso = as.data.frame(cbind(1:flies, 
                             waso_day,
                             waso_night))
  briefAwake = as.data.frame(cbind(1:flies, 
                                   brief_awake_day,
                                   brief_awake_night))
  
  names(sleepBoutons) = names(aveDuration) = names(maxDuration) = 
    names(maxDuration_zt) = names(sleepLatency) = names(ciIndex) = names(waso) = names(briefAwake) =
    c("flyID", paste0("Day", rep(1:ZT0_interval, times = 2), rep(c("-ON", "-OFF"), each = ZT0_interval)))
  
  write.table(sleepBoutons, paste0("./", subDir, "/sleep_sleepBoutons_graphpad.txt"), quote = FALSE, sep = "\t", row.names = FALSE)
  write.table(aveDuration, paste0("./", subDir, "/sleep_aveDuration_graphpad.txt"), quote = FALSE, sep = "\t", row.names = FALSE)
  write.table(maxDuration, paste0("./", subDir, "/sleep_maxDuration_graphpad.txt"), quote = FALSE, sep = "\t", row.names = FALSE)
  write.table(maxDuration_zt, paste0("./", subDir, "/sleep_maxDuration_zt_graphpad.txt"), quote = FALSE, sep = "\t", row.names = FALSE)
  write.table(sleepLatency, paste0("./", subDir, "/sleep_sleepLatency_graphpad.txt"), quote = FALSE, sep = "\t", row.names = FALSE)
  write.table(ciIndex, paste0("./", subDir, "/sleep_ciIndex_graphpad.txt"), quote = FALSE, sep = "\t", row.names = FALSE)
  write.table(waso, paste0("./", subDir, "/sleep_waso_graphpad.txt"), quote = FALSE, sep = "\t", row.names = FALSE)
  write.table(briefAwake, paste0("./", subDir, "/sleep_briefAwake_graphpad.txt"), quote = FALSE, sep = "\t", row.names = FALSE)
} else {

  day_night_id = rep(rep(c(1:as.numeric(ZT0_interval)), each = flies), times = 2)
  phase = rep(c("Lights_ON", "Lights_OFF"), each = flies * as.numeric(ZT0_interval))
  fly_id = rep(1:flies, times = as.numeric(ZT0_interval) * 2)
  
  sleeping_summary = data.frame(day = day_night_id, phase = phase, flyID = fly_id,
                                sleepBoutons = c(stack(sleep_boutons_day)$values, stack(sleep_boutons_night)$values),
                                aveDuration = c(stack(sleep_boutons_day_duration)$values, stack(sleep_boutons_night_duration)$values),
                                maxDuration = c(stack(sleep_boutons_day_duration_max)$values, stack(sleep_boutons_night_duration_max)$values),
                                maxDuration_zt = c(stack(sleep_boutons_day_duration_max_zt)$values, stack(sleep_boutons_night_duration_max_zt)$values),
                                sleepLatency = c(stack(sleep_latency_day)$values, stack(sleep_latency_night)$values),
                                ciIndex = c(stack(ci_index_day)$values, stack(ci_index_night)$values),
                                waso = c(stack(waso_day)$values, stack(waso_night)$values),
                                briefAwake = c(stack(brief_awake_day)$values, stack(brief_awake_night)$values))
  
  write.table(sleeping_summary, paste0("./", subDir, "/sleep_overall_summary.txt"), quote = FALSE, sep = "\t", row.names = FALSE)
}

rm(list = setdiff(ls(), c("defaultDir", "mainDir", "subDir", "answer",
                          "flies", "ZT0_interval",
                          "temp", "dat_activity", "dat_false_true")))

cat(paste0("\n...DATA ANALYSIS FINISHED!\n\nYour files have been saved in directory:\n", mainDir, "/", subDir,"\n"))
beep(1)
