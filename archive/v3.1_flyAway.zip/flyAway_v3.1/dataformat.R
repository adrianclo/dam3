## Create subdirectory to export files to
cat("\n-----------------------------")
cat("\nSETUP LOCATION TO STORE DATA!")
cat("\n-----------------------------")

subDir_spec = readline(prompt = "Name of your unique folder for this dataset: ")
subDir = paste0("flyData-", subDir_spec)
cat("Your data will be stored in a folder called", subDir)

subsubDir = "sleepBoutons"
if(!file.exists(subDir)) dir.create(file.path(mainDir, subDir))
if(!file.exists(subsubDir)) dir.create(file.path(mainDir, subDir, subsubDir))

cat("\n\nPlease import your data file:")

## import file and remove redundant columns
temp = read.table(file.choose(), header = FALSE)
cat("\n\nThe data file has been successfully imported!\n")

cat("\n------------------------")
cat("\nDATA FORMATTING STARTED!")
cat("\n------------------------")
cat("\nPlease select columns for analysis:\n\n")
print(head(temp))

date_ID = vector()
date_temp = readline(prompt = "Is the date spread over 3 different columns (Y or N): ")
if(tolower(date_temp) == "y") {
    date_temp = readline(prompt = "Which columns contain the date\n(numbers seperated by \",\" e.g. 2,3,4): ")
    date_temp = as.numeric(unlist(strsplit(date_temp, split = ",")))
    date_ID = paste(temp[, date_temp[1]], temp[,date_temp[2]], temp[,date_temp[3]], sep = "-")
} else {
    date_temp = readline(prompt = "Which column contains the date (only number): ")
    date_ID = temp[, as.numeric(date_temp)]
}

hour_ID = as.numeric(readline(prompt = "Which column contains the hour (only number): "))

cat("\nYour working dataset:\n")
fly_ID = (ncol(temp) - 33):ncol(temp) ## in total 32 flies that can be tested simultaneously
temp_fly_data = data.frame(temp[, fly_ID])

head(temp_fly_data)
temp_fly_data = temp_fly_data[, -apply(temp_fly_data, 2, sum) != 0] ## some rows contain no change in values: no fly?
flies = ncol(temp_fly_data)

cat(paste(flies, "flies have been identified in your data file\n\n"))
## check newly constructed data.frame
temp2 = data.frame(date = date_ID,
                   hour = temp[, hour_ID],
                   temp_fly_data)
names(temp2) = c("date", "hour", paste("fly", 1:flies, sep = "_"))
print(head(temp2))

## primary construction of sleep and awake datasets
dat_false_true = data.frame(date = temp2$date,
                            hh_mm = substr(temp2$hour, 1, 5))
dat_activity = as.data.frame(cbind(dat_false_true, temp2[, 3:ncol(temp2)]))
flies = ncol(temp2) - 2; flies
names(dat_activity)[3:dim(dat_activity)[2]] = paste("fly", 1:flies, sep = "_")

dat_activity$date = as.character(dat_activity$date)
dat_activity$hh_mm = as.character(dat_activity$hh_mm)

## ask for user input
cat("\nThe data file you chose covers the following time period:\n")
cat(dat_activity$date[1], "to", dat_activity$date[dim(dat_activity)[1]], "\n")

cat("\n---------------------------------------")
cat("\nSETUP LOCUS OF ANALYSIS AND PARAMETERS!")
cat("\n---------------------------------------")
ZT0_day = readline(prompt = "Define ZT0 (Day1 of the experiment, e.g. 26-Feb-16): "); if(nchar(ZT0_day) == 11) ZT0_day = paste0(substr(ZT0_day, 1, 7), substr(ZT0_day, 10, 11))
ZT0_hour = readline(prompt = "Define ZT0 (Lights ON, e.g. 07:30): "); if(nchar(ZT0_hour) == 4) ZT0_hour = paste0("0", ZT0_hour)
ZT0_interval = readline(prompt = "Define number of days to average over (e.g. 2): ")
ZT0_night_onset = readline(prompt = "Define lights OFF post-ZT0 (e.g. 12 [hours post-ZT0]): ")
ZT0_night_duration = readline(prompt = "Define duration of night cycle (hrs) (e.g. 12 [hours]): ")
ZT0_light_interval = c(ZT0_hour, 
                       paste0(as.numeric(substr(ZT0_hour, 1, 2)) + 12, substr(ZT0_hour, 3, 5)))

initial = which(dat_activity$date == ZT0_day & dat_activity$hh_mm == ZT0_hour)
ZT0_duration = as.numeric(ZT0_interval) * 24 * 60

## subset dataset based on user input
dat_false_true = dat_false_true[initial:(initial + ZT0_duration -1),]
dat_activity = dat_activity[initial:(initial + ZT0_duration -1),]

# dat_false_true =
#     dat_false_true %>% 
#     mutate(new_day = rep(1:as.numeric(ZT0_interval), each = 1440)) %>% 
#     mutate(new_hour = rep(1:24, each = 60, times = ZT0_interval)) %>% 
#     mutate(phase = rep(c("Day", "Night"), each = 720, times = ZT0_interval))

dat_false_true =
    dat_false_true %>% 
    mutate(day = rep(1:as.numeric(ZT0_interval), each = 1440),
           zt = rep(0:23, each = 60, times = ZT0_interval),
           phase = rep(c("Day", "Night"), each = 720, times = ZT0_interval))

dat_activity =
    dat_activity %>%
    mutate(day = rep(1:as.numeric(ZT0_interval), each = 1440),
           phase = rep(c("Day", "Night"), each = 720, times = ZT0_interval),
           zt_30min = rep(seq(from = 0, to = 23.5, by = .5), each = 30, times = ZT0_interval),
           zt = rep(0:23, each = 60, times = ZT0_interval)) %>% 
    select(date, hh_mm, day, zt, zt_30min, phase, contains("fly"))

# dat_activity = 
#     dat_activity %>%
#     mutate(new_day = dat_false_true$new_day,
#            new_hour = rep(seq(from = 1, to = 24.5, by = .5), each = 30, times = ZT0_interval),
#            phase = dat_false_true$phase) %>%
#     select(new_day, new_hour, phase, contains("fly"))

## create dataframe with TRUE-FALSE statements where >= 5 * 0 series are
on_off = as.data.frame(matrix(numeric(dim(dat_activity)[1] * flies), ncol = flies))
names(on_off) = paste("fly", 1:flies, sep = "_")

for(ii in 7:dim(dat_activity)[2]) {
    ## column extraction
    test = dat_activity[,ii]; head(test, 10)
    ## create place-holder
    zerosCol = numeric(dim(dat_activity)[1])        
    zerosCol = rep(FALSE, dim(dat_activity)[1])
    ## identify 0s
    ww = which(test == 0)
    zerosCol[ww] = TRUE; head(zerosCol, 10)
    
    ## identify series of >= 5
    tmp = rle(test)
    seriesCol = rep(tmp$lengths >= 5, times = tmp$lengths); head(seriesCol, 10)
    
    ## matches?
    on_off[,ii-6] = zerosCol & seriesCol
}

dat_false_true = as.data.frame(cbind(dat_false_true, on_off))

#' two data.frames are created:
#' dat_activity
#' dat_false_true

# print(head(dat_activity))
# print(head(dat_false_true))

cat("\n--------------------------")
cat("\nDATA FORMATTING COMPLETED!")
cat("\n--------------------------")
cat("\n\nTwo datasets have been created for subsequent analysis of sleep and awake activity.\n")
cat(paste0("These datasets - including the original dataset - have been saved in directory:\n", mainDir, "/", subDir,"\n\n"))
cat("- original.txt\n- sleep_raw.txt\n- awake_raw.txt\n\n")

rm(list = setdiff(ls(), c("defaultDir", "mainDir", "subDir", "answer",
                        "flies", "ZT0_interval",
                        "temp", "dat_activity", "dat_false_true")))

write.table(temp, paste0("./", subDir, "/original.txt"), quote = FALSE, sep = "\t", row.names = FALSE)
write.table(dat_false_true, paste0("./", subDir, "/sleep_raw.txt"), quote = FALSE, sep = "\t", row.names = FALSE)
write.table(dat_activity, paste0("./", subDir, "/awake_raw.txt"), quote = FALSE, sep = "\t", row.names = FALSE)