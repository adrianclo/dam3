cat("-- dataformatting\n")

# activity data.frame -------------------------------------------------------------------------

activity <- fread(paste0(filesDir, "\\", flyTable$import_file[aa]), header = FALSE, stringsAsFactors = FALSE)
activity %<>%
    # activity %>%
    mutate(time = ymd_hms(paste(dmy(activity$V2), hms::as.hms(activity$V3)))) %>%
    filter(between(time, # subset to data of interest
                   flyTable$start_time[aa],
                   (flyTable$start_time[aa]-1) + days(flyTable$experiment_interval[aa]))) %>%
    mutate(day = rep(1:flyTable$experiment_interval[aa], each = 60 * 24), # add date-independent parameters
           zt = rep(0:23, each = 60, times = flyTable$experiment_interval[aa]),
           zt_demi = rep(seq(0, 23.5, .5), each = 30, times = flyTable$experiment_interval[aa]),
           phase = case_when(between(zt,
                                     flyTable$zt_night_onset[aa], # nightOnset = nightDuration = 12; day = ZT0-ZT11; night = ZT12-ZT23
                                     flyTable$zt_night_onset[aa] + flyTable$zt_night_duration[aa] - 1) ~ "Night",
                             TRUE ~ "Day")) %>%
    select(time, day, zt, zt_demi, phase, V11:V42) %>%
    tbl_df()
names(activity)[6:37] = paste("fly", 1:32, sep = "_")

# activity %>% gather(fly_id, activity, -c(time:phase))

# activity <- fread(paste0(filesDir, flyTable$import_file[aa]), header = FALSE, stringsAsFactors = FALSE)
# cols = c("time", "day", "zt", "zt_demi", "phase", paste0("V", 11:42), "V10") # V10 seems a light indicator
# activity <-
#     activity[, `:=` (time = ymd_hms(paste(dmy(V2), hms::as.hms(V3))))
#              ][, `:=` (day = rep(1:flyTable$experiment_interval[aa], each = 60 * 24), # add date-independent parameters
#                          zt = rep(0:23, each = 60, times = flyTable$experiment_interval[aa]),
#                          zt_demi = rep(seq(0, 23.5, .5), each = 30, times = flyTable$experiment_interval[aa]))
#                  ][, `:=` (phase = case_when(between(zt,
#                                                      flyTable$zt_night_onset[aa], # nightOnset = nightDuration = 12; day = ZT0-ZT11; night = ZT12-ZT23
#                                                      flyTable$zt_night_onset[aa] + flyTable$zt_night_duration[aa] - 1) ~ "Night",
#                                              TRUE ~ "Day"))
#                    ][, cols, with = F]
# names(activity)[6:37] = paste("fly", 1:32, sep = "_")

ww <- which(apply(activity[,6:37], 2, sum) == 0) # check for inactive/dead flies
if(length(ww) > 0) { activity = activity[,-(ww + 5)] } # remove inactive/dead flies
flies <- names(activity)[6:ncol(activity)] # update number of flies

# assemble sleep data.frame -------------------------------------------------------------------

## TRUE for >= 5-length series of 0 (proxy for inactivity/sleep)
activity %>%
    select(contains("fly")) %>%
    mutate_all(funs(if_else(. == 0, TRUE, FALSE))) -> sleep
# ii = 1
for(ii in 1:dim(sleep)[2]) {
    identifier = rle(as.matrix(sleep)[,ii]); identifier = data_frame(values = identifier$values, lengths = identifier$lengths)
    identifier %<>%
        mutate(values = case_when(values == TRUE & lengths < 5 ~ FALSE,
                                  TRUE ~ as.logical(values)))
    sleep[,ii] = rep(identifier$values, times = identifier$lengths) }

sleep <- bind_cols(activity[,1:5], sleep)

# export --------------------------------------------------------

write.table(activity, paste0(filesDir, subDir, "\\activity_raw.txt"), quote = F, sep = "\t", row.names = F)
write.table(sleep, paste0(filesDir, subDir, "\\sleep_raw.txt"), quote = F, sep = "\t", row.names = F)
rm(identifier) # rm(list = setdiff(ls(), c("sleep", "activity", "subDir", "subsubDir", "filesDir", "flies")))