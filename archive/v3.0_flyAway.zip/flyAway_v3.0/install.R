## install packages if not available on host computer
required.packages = c("tidyverse", "gridExtra", "beepr", "doBy")
new.packages = required.packages[!(required.packages %in% installed.packages()[, "Package"])]
if(length(new.packages)) {
    cat("\n\nWARNING: Your computer does not have the required packages.")
    cat("\nR will now install the required packages. Please wait...")
    Sys.sleep(5)
    install.packages(new.packages)
    cat("\n...All required packages are installed!")
}; rm(required.packages, new.packages)

## load packages required
suppressMessages(suppressWarnings(library(dplyr)))
suppressMessages(suppressWarnings(library(ggplot2)))
suppressMessages(suppressWarnings(library(gridExtra)))
suppressMessages(suppressWarnings(library(reshape2)))
suppressMessages(suppressWarnings(library(beepr)))
suppressMessages(suppressWarnings(library(doBy)))