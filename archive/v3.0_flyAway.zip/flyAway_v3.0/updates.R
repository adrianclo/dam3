cat("\014")
cat("\n--------------------------")
cat("\nVERSION UPDATE INFORMATION")
cat("\n--------------------------\n")

cat("\nV1.0 (09-06-2016):")
cat("\n------------------")
cat("
    - read in original txt file
    - per column of original file:
    ---- identify series of >= 5 times 0's
    ---- number of such series
    ---- when these series occurred (+ duration)")

cat("\nV1.1 (15-06-2016):")
cat("\n------------------")
cat("
    - included date info
    - changed order of package installment and explanation provided\n")

cat("\nV2.0 (01-12-2016):")
cat("\n------------------")
cat("
    - earlier version required still a large proportion of manual labor
    - this version can work with user-inputs
    ---- When to start the data-collection (date and hour)
    ---- To average over how many days
    ---- Onset and duration of night cycle 
    ---- Whether more than 1 genotype is involved (still in beta-phase)
    - new dataset (sleep_pattern): min/hr sleep on an average day
    - sleep_sessions.txt also provides ave_duration of sleep beside the frequency
    - possibility of different genotypes visualization, and export of graphs (still in beta-phase)\n")

cat("\nV2.1 (28-05-2017):")
cat("\n------------------")
cat("
- specific amount of sleep during light ON and light OFF (per day)
- max_sleep_bout_duration per fly during light ON and light OFF (per day)
- latency to sleep during light ON and light OFF (per day)
- consolidation index (sleep fragmentation index) during light ON and light OFF (per day)
- wake after sleep onset (waso) during light ON and light OFF (per day)
- brief awakenings defined as 1 min epochs between two sleepings during light ON and light OFF (per day)\n")

cat("\nV2.2 (12-06-2017):")
cat("\n------------------")
cat("
- choice of unaltered file or not replaced by manual selecting relevant columns\n")

cat("\nV3.0 (22-08-2017):")
cat("\n------------------")
cat("
- include activity measures
- columns with no numeric variation are assumed to not have flies and are are automatically removed
- genotype list can be provided so flies can be sorted according to genotype (continue from V2.0)\n")

