#' Program written by: Adrian Lo
#' To read data from Trikinetic System (for fly activity)
#' REQUEST FROM: VITTORIA MARIANO
#' VERSION: 2.0

#' V1.0
#' - read in txt file
#' - per column of original file:
#' ---- identify series of >= 5 times 0's
#' ---- number of such series
#' ---- when these series occurred (+ duration)

# presets and explanations --------------------------------------------------------------------
time1 = proc.time()
terminate = FALSE

## install packages if not available on host computer
required.packages = c("dplyr", "ggplot2", "gridExtra", "reshape2", "beepr")
new.packages = required.packages[!(required.packages %in% installed.packages()[, "Package"])]
if(length(new.packages)) {
    cat("Your computer does not have the required packages.")
    cat("\nR will now install the required packages. Please wait...")
    Sys.sleep(5)
    install.packages(new.packages)
}
suppressMessages(suppressWarnings(library(dplyr)))
suppressMessages(suppressWarnings(library(ggplot2)))
suppressMessages(suppressWarnings(library(gridExtra)))
suppressMessages(suppressWarnings(library(reshape2)))
suppressMessages(suppressWarnings(library(beepr)))

## provide explanation on the purpose of the program
cat("\014")
cat("===============================\nTrikinetic System Data Analyzer\n===============================")
cat("\n\nProgram written by Adrian C. Lo, PhD\nVersion 1.0 Date: 09-06-2016\nVersion 1.1 Date: 15-06-2016\nVersion 2.0 Date: 01-12-2016")

cat("\n\nThis program will read in your \"sleepingflies\" txt file")
cat("\nand identify whether and when flies have been sleeping.")

cat("\n\nSleeping is defined as a pattern of >= 5 zeros (i.e. >= 5 minutes of inactivity).")

cat("\n\nThe program exports its output in a folder called \"sleepingflies\".")

cat("\n\nThe following output are provided by this program:")
cat("\nsleeping_flies.txt: boolean values indicate WHETHER sleeping has occurred or not.")
cat("\nsleeping_sessions.txt: shows the NUMBER of sleeping sessions during the course of the experiment.")
cat("\nfly_xx.txt: shows for each individual fly WHEN sleeping occurred as well as the sleep duration.")
cat("\nsleep_pattern.txt: shows over an AVERAGED 24hr time period HOW MANY min/hr flies are sleeping.")

cat("\n\nThe program will start now!")
cat("\n\nPlease import your data file:")

## Create subdirectory to export files to
mainDir = getwd()
subDir  = "sleepingflies"

if(!file.exists(subDir)) dir.create(file.path(mainDir, subDir))

# import file and remove redundant columns ----------------------------------------------------

temp = read.table(file.choose(), header = FALSE)
# temp = read.table("F:/sleepingflies/test_flies.txt")
# temp = read.table("F:/sleepingflies/raw data/2203161CtM001.txt")
cat("\nThe data file has been successfully imported!\n")
cat("Please specify the format:

    1. document is an untouched txt file;
    2. document is originally Excel but paste into a txt file;
    3. document is an Excel file (don't use this option yet: working on it)\n\n")
fileType = readline(prompt = "Make your choice: ")
if(fileType == "1") {
    ww = which(colSums(temp[,7:length(temp)]) == 0) # columns that do not contain fly/activity
    temp = temp[, -(ww+6)]
    
    dat_false_true = data.frame(date = paste(temp$V2, temp$V3, temp$V4, sep = "-"),
                                hh_mm = substr(temp$V5, 1, 5))
    if(nchar(as.character(dat_false_true$date[1]) != 9)) {
        cat("YOUR FILE IS NOT CORRECT!!\n")
        cat("YOUR FILE IS NOT CORRECT!!\n")
        cat("YOUR FILE IS NOT CORRECT!!\n")
        cat("YOUR FILE IS NOT CORRECT!!\n")
        cat("YOUR FILE IS NOT CORRECT!!\n")
        cat("YOUR FILE IS NOT CORRECT!!\n")
        cat("YOUR FILE IS NOT CORRECT!!\n")
        cat("YOUR FILE IS NOT CORRECT!!\n")
        cat("YOUR FILE IS NOT CORRECT!!\n")
        cat("\nRESET SCRIPT!!\n")
    }
    head(temp, 10)
    head(dat_false_true, 10)
    dat_activity = as.data.frame(cbind(dat_false_true, temp[, 7:(dim(temp)[2])]))
    flies = dim(temp)[2] - 6; flies
    names(dat_activity)[3:dim(dat_activity)[2]] = paste("fly", 1:flies, sep = "_")
    
    dat_activity$date = as.character(dat_activity$date)
    dat_activity$hh_mm = as.character(dat_activity$hh_mm)
} else if(fileType == "2") {
    ww = which(colSums(temp[,5:length(temp)]) == 0) # columns that do not contain fly/activity
    temp = temp[, -(ww+4)]
    
    dat_false_true = data.frame(date = temp$V2,
                                hh_mm = substr(temp$V3, 1, 5))
    head(temp, 10)
    head(dat_false_true, 10)
    dat_activity = as.data.frame(cbind(dat_false_true, temp[, 5:(dim(temp)[2])]))
    flies = dim(temp)[2] - 4; flies
    names(dat_activity)[3:dim(dat_activity)[2]] = paste("fly", 1:flies, sep = "_")
    
    dat_activity$date = as.character(dat_activity$date)
    dat_activity$hh_mm = as.character(dat_activity$hh_mm)
} else if(fileType == "3") {print("I said don't use this option yet, I'm working on it! :P")}


# ask for user input ------------------------------------------------------
cat("\nThe data file you chose covers the following time period:\n")
cat(dat_activity$date[1], "to", dat_activity$date[dim(dat_activity)[1]], "\n\n")

ZT0_day = readline(prompt = "Define ZT0 (e.g. 26-Feb-16): ")
if(nchar(ZT0_day) == 11) ZT0_day = paste0(substr(ZT0_day, 1, 7), substr(ZT0_day, 10, 11))
ZT0_hour = readline(prompt = "Define ZT0 (e.g. 06:30): ")
if(nchar(ZT0_hour) == 4) ZT0_hour = paste0("0", ZT0_hour)
ZT0_interval = readline(prompt = "Define number of days to average over: ")
ZT0_night_onset = readline(prompt = "Define lights off post-ZT0 (e.g. 12 [hours post-ZT0]): ")
ZT0_night_duration = readline(prompt = "Define duration of night cycle (hrs): ")
# ZT0_day = "23-Mar-16"
# ZT0_hour = "06:40"
# ZT0_interval = 2
# ZT_night = 12
if(as.numeric(ZT0_night_onset) + as.numeric(ZT0_night_duration) > 24) {
    rect = data.frame(xmin = as.numeric(ZT0_night_onset), xmax = 24,
                      ymin = -Inf, ymax = Inf)
} else {
    rect = data.frame(xmin = as.numeric(ZT0_night_onset), xmax = as.numeric(ZT0_night_onset) + as.numeric(ZT0_night_duration),
                      ymin = -Inf, ymax = Inf)
}

initial = which(dat_activity$date == ZT0_day & dat_activity$hh_mm == ZT0_hour)
ZT0_duration = as.numeric(ZT0_interval) * 24 * 60

cat(paste(flies, "flies have been identified in your data file\n"))
diff_genotypes = readline(prompt = "Your dataset contains more than 1 genotype (Y or N): ")
# diff_genotypes = "Y"
if(tolower(diff_genotypes) == "y") {
    cat("Please import your genotype file which contains the different genotypes in a pre-written format as depicted below:\n\n")
    cat("fly_ID   genotype\nfly_1    WT\nfly_2    KO\n...")
    genotype_list = read.table(file.choose(), header = TRUE)
    # genotype_df = data.frame(fly_ID = paste0("fly_", 1:flies),
    #                          genotype = sample(c("WT", "KO", "HET"), flies, replace = TRUE))
    genotype_df$genotype = toupper(genotype_df$genotype)
    
    genotypes = unique(genotype_df$genotype)
    
    cat("\n\nYour genotype file has been successfully imported!")
    cat("\nYour genotype list contains the following genotypes:\n")
    print(table(genotype_df$genotype))
    genotype_list = list()
    for(ii in 1:length(genotypes)) {
        genotype_list[[ii]] = which(genotype_df[, 2] == genotypes[ii])
        names(genotype_list)[[ii]] = genotypes[ii]
    }
}

# subset dataset based on user input --------------------------------------
time2 = proc.time()

dat_false_true = dat_false_true[initial:(initial + ZT0_duration -1),]
dat_activity = dat_activity[initial:(initial + ZT0_duration -1),]

dat_false_true$new_hour = rep(0:23, each = 60, times = ZT0_interval)
dat_activity = 
    dat_activity %>%
    mutate(new_hour = rep(seq(from = 0, to = 23.5, by = .5), each = 30, times = ZT0_interval)) %>%
    select(date, new_hour, contains("fly"))

# create dataframe with TRUE-FALSE statements where >= 5 * 0 series are -----------------------
cat("\nDATA FORMATTING/ANALYSIS IN PROGRESS...\n\n")


on_off = as.data.frame(matrix(numeric(dim(dat_activity)[1] * dim(dat_activity)[2] - dim(dat_activity)[1] * 2), ncol = flies))
names(on_off) = paste("fly", 1:flies, sep = "_")

for(ii in 3:dim(dat_activity)[2]) {
    ## column extraction
    test = dat_activity[,ii]
    head(test, 10)
    ## identify 0s
    zerosCol = numeric(dim(dat_activity)[1])        
    zerosCol = rep(FALSE, dim(dat_activity)[1])
    
    ww = which(test == 0)
    zerosCol[ww] = TRUE
    head(zerosCol, 10)
    
    ## identify series of >= 5
    tmp = rle(test)
    seriesCol = rep(tmp$lengths >= 5, times = tmp$lengths)
    head(seriesCol, 10)
    
    ## matches?
    on_off[,ii-2] = zerosCol & seriesCol
}

dat_false_true = as.data.frame(cbind(dat_false_true, on_off)); rm(on_off)
head(dat_activity[,1:14])
head(dat_false_true[,1:14])

## prepare sleep and activity datasets: 
## dat_sleep_ave contains the hourly time the average fly sleeps
## dat_activity_ave contains the 30 min average fly beam crossings 

### DAT_SLEEP
dat_sleep =
    dat_false_true %>%
    select(-hh_mm) %>%
    group_by(date, new_hour) %>%
    summarise_all(sum)
dat_sleep = as.data.frame(dat_sleep)
head(dat_sleep)
dat_sleep = 
    dat_sleep %>%
    select(-date) %>%
    group_by(new_hour) %>%
    summarise_all(mean)
dat_sleep = as.data.frame(dat_sleep)
dat_sleep_ave = data.frame(Hour = dat_sleep$new_hour)

### DAT_ACTIVITY
dat_activity_ave =
    dat_activity %>%
    group_by(date, new_hour) %>%
    summarise_all(sum)
dat_activity_ave = as.data.frame(dat_activity_ave)
dat_activity_ave =
    dat_activity_ave %>%
    select(-date) %>%
    group_by(new_hour) %>%
    summarise_all(mean)
dat_activity_ave = as.data.frame(dat_activity_ave)

if(tolower(diff_genotypes) == "y") {
    for(ii in 1:length(genotype_list)){
        dat_sleep_ave = as.data.frame(cbind(dat_sleep_ave, rowMeans(dat_sleep[, genotype_list[[ii]] + 1])))
        names(dat_sleep_ave)[ii+1] = names(genotype_list)[[ii]]
    }
    dat_sleep_ave_long = melt(dat_sleep_ave, id.vars = c("Hour")); names(dat_sleep_ave_long)[c(2,3)] = c("genotype", "ave_sleep")
    
    dat_activity_ave_temp = data.frame(Hour = dat_activity_ave$new_hour)
    for(ii in 1:length(genotype_list)){
        dat_activity_ave_temp = as.data.frame(cbind(dat_activity_ave_temp, rowMeans(dat_activity_ave[, genotype_list[[ii]] + 1])))
        names(dat_activity_ave_temp)[ii+1] = names(genotype_list)[[ii]]
    }
    dat_activity_ave_long = melt(dat_activity_ave_temp, id.vars = "Hour"); names(dat_activity_ave_long)[c(2,3)] = c("genotype", "ave_beams")
    
    g_sleep = ggplot(dat_sleep_ave_long, aes(Hour, ave_sleep, color = genotype)) +
        geom_point(alpha = 1/4) +
        geom_line() +
        geom_vline(xintercept = as.numeric(ZT0_night_onset)) +
        geom_smooth(span = .4, method = "loess") +
        labs(x = "ZT", y = "Sleep (min/hr)", title = "Sleep") +
        geom_rect(data = rect, aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax),
                  color = "grey20", alpha = .2, inherit.aes = FALSE) +
        scale_x_continuous(breaks = seq(from = 0, to = 24, by = 2),
                           limits = c(0,24)) +
        theme_bw() + 
        theme(plot.title = element_text(hjust = 0.5, size = 20),
              panel.grid = element_blank())
    
    g_beam = ggplot(dat_activity_ave_long, aes(Hour, ave_beams, colour = genotype)) +
        geom_point(alpha = 1/4) +
        geom_line() +
        geom_vline(xintercept = as.numeric(ZT0_night_onset)) +
        geom_smooth(span = .3, method = "loess") +
        labs(x = "ZT", y = "Beam crossings (n)", title = "Activity") +
        geom_rect(data = rect, aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax),
                  color = "grey20", alpha = .2, inherit.aes = FALSE) +
        scale_x_continuous(breaks = seq(from = 0, to = 24, by = 2),
                           limits = c(0,24)) +
        theme_bw() + 
        theme(plot.title = element_text(hjust = 0.5, size = 20),
              panel.grid = element_blank())
} else {
    dat_sleep_ave = as.data.frame(cbind(dat_sleep_ave, rowMeans(dat_sleep[, 2:ncol(dat_sleep)]))); names(dat_sleep_ave)[2] = "ave_sleep"
    g_sleep = ggplot(dat_sleep_ave, aes(Hour, ave_sleep)) +
        geom_point(alpha = 1/4) +
        geom_line() +
        geom_vline(xintercept = as.numeric(ZT0_night_onset)) +
        geom_smooth(span = .4, method = "loess") +
        labs(x = "ZT", y = "Sleep (min/hr)", title = "Sleep") +
        geom_rect(data = rect, aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax),
                  color = "grey20", alpha = .2, inherit.aes = FALSE) +
        scale_x_continuous(breaks = seq(from = 0, to = 24, by = 2),
                           limits = c(0,24)) +
        theme_bw() + 
        theme(plot.title = element_text(hjust = 0.5, size = 20),
              panel.grid = element_blank())
    
    g_beam = ggplot(dat_activity_ave, aes(new_hour, rowMeans(dat_activity_ave[,2:ncol(dat_activity_ave)]))) +
        geom_point(alpha = 1/4) +
        geom_line() +
        geom_vline(xintercept = as.numeric(ZT0_night_onset)) +
        geom_smooth(span = .3, method = "loess") +
        labs(x = "ZT", y = "Beam crossings (n)", title = "Activity") +
        geom_rect(data = rect, aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax),
                  color = "grey20", alpha = .2, inherit.aes = FALSE) +
        scale_x_continuous(breaks = seq(from = 0, to = 24, by = 2),
                           limits = c(0,24)) +
        theme_bw() + 
        theme(plot.title = element_text(hjust = 0.5, size = 20),
              panel.grid = element_blank())
}

## providing graphical visualizations
jpeg("./sleepingflies/sleep_plot.jpg", width = 600, height = 480)
print(g_sleep)
dev.off()
jpeg("./sleepingflies/beam_plot.jpg", width = 600, height = 480)
print(g_beam)
dev.off()
grid.arrange(g_sleep, g_beam, nrow = 2)
jpeg("./sleepingflies/sleep_active_plot.jpg", width = 600, height = 480)
grid.arrange(g_sleep, g_beam, nrow = 2)
dev.off()

write.table(dat_false_true, "./sleepingflies/sleeping_flies.txt", quote = FALSE, sep = "\t", row.names = FALSE)
write.table(dat_sleep, "./sleepingflies/sleep_pattern.txt", quote = FALSE, sep = "\t", row.names = FALSE)

# how many sleeping sessions? -----------------------------------------------------------------

sleep_sessions = numeric()
sleep_sessions_duration = numeric()
for(ii in 4:dim(dat_false_true)[2]) {
    zzz = rle(dat_false_true[,ii])
    sleep_sessions[ii-3] = sum(zzz$values == TRUE)
    sleep_sessions_duration[ii-3] = round(mean(zzz$lengths[zzz$values == TRUE]), 2)
}
sleep_sessions = data.frame(flyID = paste("fly", 1:flies, sep = "_"),
                            number_session = sleep_sessions, ave_duration = sleep_sessions_duration)

write.table(sleep_sessions, "./sleepingflies/sleep_sessions.txt", quote = FALSE, sep = "\t", row.names = FALSE)

# when were these sleep sessions? -------------------------------------------------------------

for(ii in 4:dim(dat_false_true)[2]) {
    
    lengths = rle(dat_false_true[,ii])$lengths
    values = rle(dat_false_true[,ii])$values
    
    when = data.frame(lengths = lengths, values = values) %>%
        mutate(rowValue = cumsum(lengths) - (lengths - 1))
    head(when)
    ww = when$rowValue
    
    when = mutate(when,
                  date = dat_false_true$date[ww],
                  hour = dat_false_true$hh_mm[ww])
    head(when)
    when = when %>%
        filter(values == TRUE) %>%
        select(c(rowValue, date, hour, lengths))
    head(when)
    
    write.table(when, paste0("./sleepingflies/fly_", ii-3, ".txt"), quote = FALSE, sep = "\t", row.names = FALSE)
}

# final statements ----------------------------------------------------------------------------

time3 = proc.time()
cat(paste0("...DATA FORMATTING/ANALYSIS FINISHED!\nYour files have been saved in directory: ", mainDir, "/sleepingflies\n"))
cat("\nTime that has elapsed once you started the script:\n")
print(time3 - time1)
cat("\nTime that has elapsed to perform the data formatting/analysis:\n")
print(time3 - time2)
beep(5)