library(tidyverse)

# original file: test_30317CtM002
# 31-Mar-17; 07:31

sleep_boutons_length_night_df = read.table("./flyAway_v3.1/flyData-testhome01/sleep_boutons_length_NIGHT.txt", header = T, sep = "\t")
sleep_boutons_length_night_df %>% filter(bouton_length < 5)  # check fly_17
sleep_boutons_length_night_df %>% filter(fly == "fly_17")

dat_false_true = read.table("./flyAway_v3.1/flyData-testhome01/sleep_raw.txt", header = T, sep = "\t")
dat_activity = read.table("./flyAway_v3.1/flyData-testhome01/awake_raw.txt", header = T, sep = "\t")

dat_false_true %>% head

dat_false_true %>%
  filter(phase == "Night") %>% 
  select(fly_17) %>% unlist %>% unname %>% rle -> fly17
fly17 = data.frame(values = fly17$values, lengths = fly17$lengths)
fly17 %>% filter(values == TRUE)



fly17 %>% filter(values == TRUE) -> test1; sum(test1[,2])
sleep_boutons_length_night_df %>% filter(fly == "fly_17") -> test2; sum(test2[,2])
