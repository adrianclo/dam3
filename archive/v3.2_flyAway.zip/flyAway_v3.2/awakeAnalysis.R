cat("\n---------------")
cat("\nAWAKE ANALYSIS!")
cat("\n---------------")

cat("\nDATA ANALYSIS STARTED...\n")

## dat_activity_ave contains the 30 min summed beam crossings for each fly per day
## dat_activity_spec contains the 30 min average beam crossings for each fly
dat_activity_ave =
    dat_activity %>%
    select(-c(date, hh_mm, phase, zt)) %>%
    group_by(day, zt_30min) %>%
    summarise_all(sum)
dat_activity_ave = as.data.frame(dat_activity_ave)
dat_activity_ave_pattern = 
    dat_activity_ave %>%
    select(-day) %>%
    group_by(zt_30min) %>%
    summarise_all(mean)
dat_activity_ave_pattern = as.data.frame(dat_activity_ave_pattern)

## activity split according to day / phase (+ TOTAL)
dat_activity_spec_1 = 
    dat_activity %>% 
    select(-c(date, hh_mm, zt, zt_30min)) %>% 
    group_by(day, phase) %>%
    summarise_all(sum)
dat_activity_spec_1 = as.data.frame(dat_activity_spec_1)

dat_activity_spec_2 = 
    dat_activity %>% 
    select(-c(date, hh_mm, zt, zt_30min, phase)) %>% 
    group_by(day) %>% 
    summarise_all(sum) %>% 
    mutate(phase = "TOTAL") %>% 
    select(day, phase, contains("fly"))

dat_activity_spec = orderBy(~day,
                            data = as.data.frame(rbind(dat_activity_spec_1, dat_activity_spec_2)))

#' Evening anticipation index: 
#' (ZT9 to ZT12) - (ZT6 to ZT9) [1] / (ZT6 to ZT12) [2]
evening_1 =
    dat_activity %>% 
    select(-c(date, hh_mm, zt_30min, phase)) %>% filter(zt >= 6 & zt < 12) %>% 
    mutate(period = factor(case_when(zt >= 6 & zt < 9 ~ "pre",
                                     zt >= 9 & zt < 12 ~ "post"), levels = c("pre", "post"))) %>% 
    select(-zt) %>% group_by(day, period) %>% summarise_all(sum) %>% 
    select(-period) %>% group_by(day) %>% summarise_all(diff) %>% 
    mutate(period = "DIFF") %>% select(day, period, contains("fly")) # post - pre
evening_2 = 
    dat_activity %>% 
    select(-c(date, hh_mm, zt_30min, phase)) %>% filter(zt >= 6 & zt < 12) %>% 
    mutate(period = factor(case_when(zt >= 6 & zt < 9 ~ "pre",
                                     zt >= 9 & zt < 12 ~ "post"), levels = c("pre", "post"))) %>% 
    select(-zt) %>% group_by(day, period) %>% summarise_all(sum) %>% 
    select(-period) %>% group_by(day) %>% summarise_all(sum) %>% 
    mutate(period = "TOTAL") %>% select(day, period, contains("fly"))

evening = orderBy(~day, data = as.data.frame(rbind(evening_1, evening_2)))

evening_anticipation = as.data.frame(matrix(numeric(flies * 2 + 2), ncol = flies + 1))
for(ii in 1:max(evening$day)) {
    temp = 
        evening %>% 
        filter(day == ii) %>% 
        select(-period)
    evening_anticipation[ii,] = round(temp[1,] / temp[2,], 4)
    evening_anticipation[ii, 1] = ii
    names(evening_anticipation) = names(temp)
}; evening_anticipation$anticipation = "evening"

#' Morning anticipation index:
#' (ZT21 to ZT0) - (ZT18 to Z21) [1] / (ZT18 to ZT0) [2]
morning_1 =
    dat_activity %>% 
    select(-c(date, hh_mm, zt_30min, phase)) %>% filter(zt >= 18 & zt <= 23) %>% 
    mutate(period = factor(case_when(zt >= 18 & zt < 21 ~ "pre",
                                     zt >= 21 & zt <= 23 ~ "post"), levels = c("pre", "post"))) %>% 
    select(-zt) %>% group_by(day, period) %>% summarise_all(sum) %>% 
    select(-period) %>% group_by(day) %>% summarise_all(diff) %>% 
    mutate(period = "DIFF") %>% select(day, period, contains("fly")) # post - pre
morning_2 = 
    dat_activity %>% 
    select(-c(date, hh_mm, zt_30min, phase)) %>% filter(zt >= 18 & zt <= 23) %>% 
    mutate(period = factor(case_when(zt >= 18 & zt < 21 ~ "pre",
                                     zt >= 21 & zt <= 23 ~ "post"), levels = c("pre", "post"))) %>% 
    select(-zt) %>% group_by(day, period) %>% summarise_all(sum) %>% 
    select(-period) %>% group_by(day) %>% summarise_all(sum) %>% 
    mutate(period = "TOTAL") %>% select(day, period, contains("fly"))

morning = orderBy(~day, data = as.data.frame(rbind(morning_1, morning_2)))

morning_anticipation = as.data.frame(matrix(numeric(flies * 2 + 2), ncol = flies + 1))
for(ii in 1:max(morning$day)) {
    temp = 
        morning %>% 
        filter(day == ii) %>% 
        select(-period)
    morning_anticipation[ii,] = round(temp[1,] / temp[2,], 4)
    morning_anticipation[ii, 1] = ii
    names(morning_anticipation) = names(temp)
}; morning_anticipation$anticipation = "morning"

anticipation = as.data.frame(rbind(morning_anticipation, evening_anticipation))
anticipation = select(anticipation, anticipation, day, contains("fly"))

# output ------------------------------------------------------------------
graphpad = readline(prompt = "Output in graphpad format (y or n): ")
flyID = as.numeric(gsub("fly_", "", colnames(temp_fly_data)))

if(tolower(graphpad) == "y") {
    anticipation = as.data.frame(cbind(flyID, 
                                       t(morning_anticipation[,-c(1, ncol(morning_anticipation))]),
                                       t(evening_anticipation[,-c(1, ncol(evening_anticipation))])))
    
    dat_activity_spec = as.data.frame(cbind(flyID,
                                       t(arrange(dat_activity_spec_1, phase)[,-c(1:2)]),
                                       t(dat_activity_spec_2[,-c(1:2)])))
    
    names(anticipation) = c("flyID", paste0("morning_", 1:as.numeric(ZT0_interval)), paste0("evening_", 1:as.numeric(ZT0_interval)))
    names(dat_activity_spec) = c("flyID", 
                            paste0(rep(c("Day", "Night"), each = as.numeric(ZT0_interval)), "_", rep(1:as.numeric(ZT0_interval), times = 2)),
                            paste0(rep("TOTAL_", times = as.numeric(ZT0_interval)), 1:as.numeric(ZT0_interval)))
    
    write.table(anticipation, paste0("./", subDir, "/awake_anticipation_graphpad.txt"), quote = F, sep = "\t", row.names = F)
    write.table(dat_activity_spec, paste0("./", subDir, "/awake_cycle_graphpad.txt"), quote = F, sep = "\t", row.names = F)
    write.table(dat_activity_ave, paste0("./", subDir, "/awake_pattern.txt"), quote = F, sep = "\t", row.names = F)
}

if(tolower(graphpad == "n")) {
    write.table(anticipation, paste0("./", subDir, "/awake_anticipation.txt"), quote = FALSE, sep = "\t", row.names = FALSE)
    write.table(dat_activity_spec, paste0("./", subDir, "/awake_cycle.txt"), quote = FALSE, sep = "\t", row.names = FALSE)
    write.table(dat_activity_ave, paste0("./", subDir, "/awake_pattern.txt"), quote = FALSE, sep = "\t", row.names = FALSE)
} else {
    dat_activity_spec = t(dat_activity_spec); dat_activity_spec = dat_activity_spec[-c(1:2),]
    dat_activity_spec = as.data.frame(dat_activity_spec)
    for(uu in 1:ncol(dat_activity_spec)) {
        dat_activity_spec[,uu] = as.numeric(dat_activity_spec[,uu])
    }
    names(dat_activity_spec)
}

rm(list = setdiff(ls(), c("defaultDir", "mainDir", "subDir", "answer",
                        "flies", "ZT0_interval", "temp_fly_data", "flyID",
                        "evening",
                        "temp", "dat_activity", "dat_false_true")))

cat(paste0("\n...DATA ANALYSIS FINISHED!\nYour files have been saved in directory:\n", mainDir, "/", subDir,"\n"))
beep(1)