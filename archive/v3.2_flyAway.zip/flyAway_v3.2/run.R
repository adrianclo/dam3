##-------------------------------------------------------------------##
##  WRITTEN BY: ADRIAN C. LO, PhD                                    ##               
##  REQUEST FROM: VITTORIA MARIANO                                   ##
##  PURPOSE: To read data from Trikinetic System (for fly activity)  ##
##  VERSION: 3.2                                                     ##
##-------------------------------------------------------------------##

cat("\014")
cat("===============================\n")
cat("TRIKINETIC SYSTEM DATA ANALYZER\n")
cat("===============================")
cat("\nWRITTEN BY: ADRIAN C. LO, PhD\n")
cat("\nVersion 1.0: 09-06-2016\n         .1: 15-06-2016")
cat("\nVersion 2.0: 01-12-2016\n         .1: 28-05-2017\n         .2: 12-06-2017")
cat("\nVersion 3.0: 22-08-2017\n         .1: 10-05-2018\n         .2: 29-05-2018")
cat("\nPURPOSE: This program will read in your .txt file containing SLEEP and AWAKE activity in flies")
cat("\n         Data are exported to a folder called \"flyData-$$\".")

rm(list = ls())
defaultDir = getwd()
if(grepl(pattern = "flyAway_v3.2", x = defaultDir)) {
    setwd("..")
    defaultDir = getwd()
}
setwd("flyAway_v3.2")
mainDir = getwd()

source("install.R") # presets

answer = 1
while(answer != 9) {
    cat("\n\nWhat do you wish to do?\n
    Presets:
    0. Import (new) .txt file
    
    Analyse:
    1. SLEEP activity
    2. AWAKE activity
    3. BOTH activities
    
    Overview:
    4. Output files/parameters and description
    5. Version updates

    9. Stop the program\n\n")
    
    answer = readline(prompt = "run >> ")
    if(answer == 0) source("dataformat_2.R")
    else if(answer == 1) source("sleepAnalysis_2.R")
    else if(answer == 2) source("awakeAnalysis.R")
    else if(answer == 3) {source("sleepAnalysis_2.R"); source("awakeAnalysis.R")}
    else if(answer == 4) source("readMe.R")
    else if(answer == 5) source("updates.R") # contains update information of each version
    else if(answer == 9) break
    else cat("Wrong input! Please try again...")
}

cat("\n
    ENG: Finished!
    FR:  Fini!
    NL:  Gedaan!
    IT:  Finito!")
beep(8)

setwd(defaultDir)
rm(list = setdiff(ls(), c("defaultDir")))
