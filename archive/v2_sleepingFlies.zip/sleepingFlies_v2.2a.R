##-------------------------------------------------------------------##
##  WRITTEN BY: ADRIAN C. LO, PhD                                    ##               
##  REQUEST FROM: VITTORIA MARIANO                                   ##
##  PURPOSE: To read data from Trikinetic System (for fly activity)  ##
##  VERSION: 2.2                                                     ##
##-------------------------------------------------------------------##

#' V1.0
#' - read in txt file
#' - per column of original file:
#' ---- identify series of >= 5 times 0's
#' ---- number of such series
#' ---- when these series occurred (+ duration)

#' V1.1 updates:
#' - included date info
#' - changed order of package installment and explanation provided

#' V2.0 updates:
#' - Earlier version required still a large proportion of manual labor
#' - This version can work with user-inputs
#' ---- When to start the data-collection (date and hour)
#' ---- To average over how many days
#' ---- Onset and duration of night cycle 
#' ---- Whether more than 1 genotype is involved (still in beta-phase)
#' - new dataset (sleep_pattern): min/hr sleep on an average day
#' - sleep_sessions.txt also provides ave_duration of sleep beside the frequency
#' - Possibility of different genotypes visualization, and export of graphs (still in beta-phase)

#' V2.1 updates:
#' - specific amount of sleep during light ON and light OFF (per day)
#' - max_sleep_bout_duration per fly during light ON and light OFF (per day)
#' - latency to sleep during light ON and light OFF (per day)
#' - consolidation index (sleep fragmentation index) during light ON and light OFF (per day)
#' - wake after sleep onset (waso) during light ON and light OFF (per day)
#' - brief awakenings defined as 1 min epochs between two sleepings during light ON and light OFF (per day)

#' V2.2 updates:
#' - choice of unaltered file or not replaced by manual selecting relevant columns
#' - genotype list can be provided so flies can be sorted according to genotype (continue from V2.0)

# presets and explanations --------------------------------------------------------------------
time1 = proc.time()

## install packages if not available on host computer
required.packages = c("dplyr", "ggplot2", "gridExtra", "reshape2", "beepr")
new.packages = required.packages[!(required.packages %in% installed.packages()[, "Package"])]
if(length(new.packages)) {
    cat("Your computer does not have the required packages."); cat("\nR will now install the required packages. Please wait...")
    Sys.sleep(5)
    install.packages(new.packages)
}; rm(required.packages, new.packages)
suppressMessages(suppressWarnings(library(dplyr)))
suppressMessages(suppressWarnings(library(ggplot2)))
suppressMessages(suppressWarnings(library(gridExtra)))
suppressMessages(suppressWarnings(library(reshape2)))
suppressMessages(suppressWarnings(library(beepr)))

## provide explanation on the purpose of the program
cat("\014")
cat("===============================\nTrikinetic System Data Analyzer\n===============================")
cat("\n\nProgram written by ADRIAN C. LO, PhD")
cat("\nVersion 1.0 Date: 09-06-2016\nVersion 1.1 Date: 15-06-2016")
cat("\nVersion 2.0 Date: 01-12-2016\nVersion 2.1 Date: 28-05-2017")
cat("\nVersion 2.2 Date: 28-06-2017")
cat("\n\nThis program will read in your \"sleepingflies\" txt file")
cat("\nand identify whether and when flies have been sleeping.")
cat("\n\nSleeping is defined as a pattern of >= 5 zeros (i.e. >= 5 minutes of inactivity).")
cat("\n\nThe program exports its output in a folder called \"sleepingflies-XXX\".")
cat("\n\nThe following output are provided by this program:")
cat("\n1. sleeping_flies.txt:\n   Booleans indicate WHETHER sleeping has occurred or not.")
cat("\n2. sleep_cycle.txt:\n   Total amount of sleep during LIGHT ON and LIGHT OFF conditions for each day.")
cat("\n3. sleep_development.txt:\n   Time-lapse of sleep (in min) across the experiment.") 
cat("\n4. sleep_pattern.txt:\n   Average day of sleep in each individual fly.") 
cat("\n5. ave_sleeping_sessions.txt:\n   NUMBER and DURATION of sleeping sessions during the course of the experiment") 
cat("\n   in LIGHT ON and LIGHT OFF conditions.")
cat("\n6. sleeping_flies_summary.txt:\n   NUMBER, DURATION, LATENCY, CI-INDEX, WASO and BRIEF AWAKENINGS during LIGHT ON") 
cat("\n   and LIGHT OFF conditions for each seperate day.")
cat("\n7. fly_xx.txt:\n   WHEN and DURATION of sleep for each individual fly.") 
cat("\n\nThe program will start now!")

## Create subdirectory to export files to
subDir_spec = readline(prompt = "Name of your unique folder for this dataset: ")
subDir = paste0("sleepingflies-", subDir_spec)
cat("Your data will be stored in a folder called", subDir)

mainDir = getwd(); subsubDir = "sleepsessions"
if(!file.exists(subDir)) dir.create(file.path(mainDir, subDir))
if(!file.exists(subsubDir)) dir.create(file.path(mainDir, subDir, subsubDir))

cat("\n\nPlease import your data file:")

# source("test.R")

# import file and remove redundant columns ----------------------------------------------------
temp = read.table(file.choose(), header = FALSE)
cat("\nThe data file has been successfully imported!\n"); cat("Please select columns for analysis\n:")
print(head(temp))

date_ID = vector()
date_temp = readline(prompt = "Is the date spread over 3 different columns (Y or N): ")
if(tolower(date_temp) == "y") {
    date_temp = readline(prompt = "Which columns contain the date\n(numbers seperated by \",\" e.g. 2,3,4): ")
    date_temp = as.numeric(unlist(strsplit(date_temp, split = ",")))
    date_ID = paste(temp[,date_temp[1]], temp[,date_temp[2]], temp[,date_temp[3]], sep = "-")
} else {
    date_temp = readline(prompt = "Which column contains the date (only number): ")
    date_ID = temp[,as.numeric(date_temp)]
}

hour_ID = as.numeric(readline(prompt = "Which column contains the hour (only number): "))

fly_correct = "N"
fly_ID_first = fly_ID_last = numeric()
while(tolower(fly_correct) == "n") {
print(head(temp))
fly_ID_first = as.numeric(readline(prompt = "Which is the first column with fly data (only number): "))
fly_ID_last = as.numeric(readline(prompt = "Which is the last column with fly data (only number): "))

fly_correct = readline(prompt = "Are you sure with your fly column selection (Y or N): ")
}

## ------------------------------------------------------ ##
## DOUBLE CHECK removing intermitting no fly data columns ##
## ------------------------------------------------------ ##

temp_fly = temp[, fly_ID_first:fly_ID_last]
fly_data = temp_fly[,apply(temp_fly, 2, var) != 0]; rm(temp_fly) ## intermittent no fly data columns removed
cat("Your working dataset\n")
temp = as.data.frame(cbind(date = date_ID,
                           hour = temp[,hour_ID],
                           fly_data))
head(temp)

diff_genotypes = readline(prompt = "are more than 1 genotype involved (Y or N): ")
if(tolower(diff_genotypes) == "y") {
    cat("\n\nPlease import your file that contains the genotypes (row-wise):")
    genotype_list = read.table(file.choose(), header = FALSE)
} else genotype_list = rep("same", ncol(temp) - 2)

## --------------------------------------------------------- ##
## CONTINUE code to add genotype information to be processed ##
## --------------------------------------------------------- ##

dat_false_true = data.frame(date = temp$date,
                            hh_mm = substr(temp$hour, 1, 5))

dat_activity = as.data.frame(cbind(dat_false_true, temp[, 3:ncol(temp)]))
flies = ncol(temp) - 2; flies
cat(paste(flies, "flies have been identified in your data file\n"))
names(dat_activity)[3:dim(dat_activity)[2]] = paste("fly", 1:flies, sep = "_")

dat_activity$date = as.character(dat_activity$date)
dat_activity$hh_mm = as.character(dat_activity$hh_mm)

# ask for user input ------------------------------------------------------
cat("\nThe data file you chose covers the following time period:\n")
cat(dat_activity$date[1], "to", dat_activity$date[dim(dat_activity)[1]], "\n\n")

ZT0_day = readline(prompt = "Define ZT0 (e.g. 26-Feb-16): "); if(nchar(ZT0_day) == 11) ZT0_day = paste0(substr(ZT0_day, 1, 7), substr(ZT0_day, 10, 11))
ZT0_hour = readline(prompt = "Define ZT0 (e.g. 06:30): "); if(nchar(ZT0_hour) == 4) ZT0_hour = paste0("0", ZT0_hour)
ZT0_interval = readline(prompt = "Define number of days to average over (e.g. 2): ")ZT0_night_onset = readline(prompt = "Define lights off post-ZT0 (e.g. 12 [hours post-ZT0]): ")
ZT0_night_duration = readline(prompt = "Define duration of night cycle (hrs) (e.g. 12 [hours]): ")
ZT0_light_interval = c(ZT0_hour, 
                       paste0(as.numeric(substr(ZT0_hour, 1, 2)) + 12, substr(ZT0_hour, 3, 5)))

initial = which(dat_activity$date == ZT0_day & dat_activity$hh_mm == ZT0_hour)
ZT0_duration = as.numeric(ZT0_interval) * 24 * 60

# subset dataset based on user input --------------------------------------
time2 = proc.time()

dat_false_true = dat_false_true[initial:(initial + ZT0_duration -1),]
dat_activity = dat_activity[initial:(initial + ZT0_duration -1),]

## still empty data.frame
dat_false_true =
    dat_false_true %>% 
    mutate(new_day = rep(1:as.numeric(ZT0_interval), each = 1440)) %>% 
    mutate(new_hour = rep(1:24, each = 60, times = ZT0_interval)) %>% 
    mutate(phase = rep(c("Day", "Night"), each = 720, times = ZT0_interval))

dat_activity = 
    dat_activity %>%
    mutate(new_hour = rep(seq(from = 1, to = 24.5, by = .5), each = 30, times = ZT0_interval)) %>%
    select(date, new_hour, contains("fly"))

# create dataframe with TRUE-FALSE statements where >= 5 * 0 series are -----------------------
cat("\nDATA FORMATTING/ANALYSIS IN PROGRESS...\n\n")

on_off = as.data.frame(matrix(numeric(dim(dat_activity)[1] * dim(dat_activity)[2] - dim(dat_activity)[1] * 2), ncol = flies))
names(on_off) = paste("fly", 1:flies, sep = "_")

for(ii in 3:dim(dat_activity)[2]) {
    ## column extraction
    test = dat_activity[,ii]; head(test, 10)
    ## identify 0s
    zerosCol = numeric(dim(dat_activity)[1])        
    zerosCol = rep(FALSE, dim(dat_activity)[1])
    
    ww = which(test == 0)
    zerosCol[ww] = TRUE; head(zerosCol, 10)
    
    ## identify series of >= 5
    tmp = rle(test)
    seriesCol = rep(tmp$lengths >= 5, times = tmp$lengths); head(seriesCol, 10)
    
    ## matches?
    on_off[,ii-2] = zerosCol & seriesCol
}

dat_false_true = as.data.frame(cbind(dat_false_true, on_off)); rm(on_off)
head(dat_activity[,1:14], 20); head(dat_false_true[,1:17], 20)

## prepare sleep and activity datasets: 
## dat_sleep_ave contains the hourly average sleeping time for each fly
## dat_activity_ave contains the 30 min average fly beam crossings 

### DAT_SLEEP
ave_dat_sleep =
    dat_false_true %>%
    select(-c(date, hh_mm, phase)) %>%
    group_by(new_day, new_hour) %>%
    summarise_all(sum)
ave_dat_sleep = as.data.frame(ave_dat_sleep)
ave_dat_sleep =
    ave_dat_sleep %>% 
    select(-new_day) %>% 
    group_by(new_hour) %>% 
    summarise_all(mean)
ave_dat_sleep = as.data.frame(ave_dat_sleep)
head(ave_dat_sleep[,1:15], 20)

dat_sleep =
    dat_false_true %>%
    select(-c(date, hh_mm, phase)) %>%
    group_by(new_day, new_hour) %>%
    summarise_all(sum)
dat_sleep = as.data.frame(dat_sleep)
head(dat_sleep[,1:15], 20)

## Daytime (ZT0-ZT12) and Nighttime sleep (ZT12-ZT24): SUM over phase PER DAY
dat_sleep_spec =
    dat_sleep %>%
    mutate(phase = rep(c("Day", "Night"), each = 12, times = ZT0_interval)) %>%
    select(-new_hour) %>%
    group_by(new_day, phase) %>%
    summarise_all(sum)

### DAT_ACTIVITY
dat_activity_ave =
    dat_activity %>%
    group_by(date, new_hour) %>%
    summarise_all(sum)
dat_activity_ave = as.data.frame(dat_activity_ave)
dat_activity_ave =
    dat_activity_ave %>%
    select(-date) %>%
    group_by(new_hour) %>%
    summarise_all(mean)
dat_activity_ave = as.data.frame(dat_activity_ave)

write.table(dat_false_true, paste0("./",subDir,"/sleeping_flies.txt"), quote = FALSE, sep = "\t", row.names = FALSE)
write.table(dat_sleep, paste0("./",subDir,"/sleep_development.txt"), quote = FALSE, sep = "\t", row.names = FALSE)
write.table(dat_sleep_spec, paste0("./",subDir,"/sleep_cycle.txt"), quote = FALSE, sep = "\t", row.names = FALSE)
write.table(ave_dat_sleep, paste0("./",subDir,"/sleep_pattern.txt"), quote = FALSE, sep = "\t", row.names = FALSE)

# how many sleeping sessions? -----------------------------------------------------------------
## DAY and NIGHT sleeping sessions + MEAN DURATION per session (TOTAL)
total_sleep_sessions_day = numeric()
total_sleep_sessions_day_duration = numeric()
total_sleep_sessions_day_duration_max = numeric()
total_sleep_sessions_night = numeric()
total_sleep_sessions_night_duration = numeric()
total_sleep_sessions_night_duration_max = numeric()

for(ii in 6:dim(dat_false_true)[2]) {
    zzz_day = rle(dat_false_true[dat_false_true$phase == "Day", ii])
    total_sleep_sessions_day[ii-5] = sum(zzz_day$values == TRUE)
    total_sleep_sessions_day_duration[ii-5] = round(mean(zzz_day$lengths[zzz_day$values == TRUE]), 2)
    total_sleep_sessions_day_duration_max[ii-5] = max(zzz_day$lengths[zzz_day$values == TRUE])
    
    zzz_night = rle(dat_false_true[dat_false_true$phase == "Night", ii])
    total_sleep_sessions_night[ii-5] = sum(zzz_night$values == TRUE)
    total_sleep_sessions_night_duration[ii-5] = round(mean(zzz_night$lengths[zzz_night$values == TRUE]), 2)
    total_sleep_sessions_night_duration_max[ii-5] = max(zzz_night$lengths[zzz_night$values == TRUE])
}

ave_sleep_sessions = data.frame(flyID = paste("fly", 1:flies, sep = "_"),
                                day_session = total_sleep_sessions_day, day_ave_duration = total_sleep_sessions_day_duration, day_max_duration = total_sleep_sessions_day_duration_max,
                                night_session = total_sleep_sessions_night, night_ave_duration = total_sleep_sessions_night_duration, night_max_duration = total_sleep_sessions_night_duration_max)
write.table(ave_sleep_sessions, paste0("./",subDir,"/ave_sleep_sessions.txt"), quote = FALSE, sep = "\t", row.names = FALSE)

## DAY and NIGHT sleeping sessions + MEAN duration per session (per day)
phase = rep(c("Lights_ON", "Lights_OFF"), each = flies, times = as.numeric(ZT0_interval))
day_night_id = rep(c(1:as.numeric(ZT0_interval)), each = flies * 2)
fly_id = rep(1:flies, times = as.numeric(ZT0_interval) * 2)

sleep_sessions_day = sleep_sessions_day_duration = sleep_sessions_day_duration_max = data.frame()
sleep_sessions_night = sleep_sessions_night_duration = sleep_sessions_night_duration_max = data.frame()

sleep_latency_day = sleep_latency_night = data.frame()
ci_index_day = ci_index_night = data.frame()
waso_day = waso_night = data.frame()
brief_awake_day = brief_awake_night = data.frame()

for(jj in 1:as.numeric(ZT0_interval)){
    ## subset per day
    temp_file = dat_false_true[dat_false_true$new_day == jj,]
    for(ii in 6:dim(dat_false_true)[2]) {
        ## subset per day/night phase
        zzz_day = rle(temp_file[temp_file$phase == "Day", ii])
        zzz_night = rle(temp_file[temp_file$phase == "Night", ii])
        
        sleep_sessions_day[ii-5,jj] = sum(zzz_day$values == TRUE)
        sleep_sessions_day_duration[ii-5,jj] = round(mean(zzz_day$lengths[zzz_day$values == TRUE]), 2)
        sleep_sessions_day_duration_max[ii-5,jj] = max(zzz_day$lengths[zzz_day$values == TRUE])
        
        sleep_sessions_night[ii-5,jj] = sum(zzz_night$values == TRUE)
        sleep_sessions_night_duration[ii-5,jj] = round(mean(zzz_night$lengths[zzz_night$values == TRUE]), 2)
        sleep_sessions_night_duration_max[ii-5,jj] = max(zzz_night$lengths[zzz_night$values == TRUE])
        
        ## latency to sleep during the day/night (per day)
        # sleep_latency_day[ii-5,jj] = zzz_day[[1]][1] + 1
        # sleep_latency_night[ii-5,jj] = zzz_night[[1]][1] + 1
        if(zzz_day$values[1] == TRUE) {
            sleep_latency_day[ii-5,jj] = 0
        } else sleep_latency_day[ii-5,jj] = zzz_day$lengths[1] + 1
        if(zzz_night$values[1] == TRUE) {
            sleep_latency_night[ii-5,jj] = 0
        } else sleep_latency_night[ii-5,jj] = zzz_night$lengths[1] + 1
        
        ## consolidation_index during the day/night (per day)
        ci_index_day[ii-5,jj] = sum(zzz_day$lengths[zzz_day$values == TRUE]^2) / sum(zzz_day$lengths[zzz_day$values == TRUE])
        ci_index_night[ii-5,jj] = sum(zzz_night$lengths[zzz_night$values == TRUE]^2) / sum(zzz_night$lengths[zzz_night$values == TRUE])
        
        ## wake after sleep onset (WASO)
        waso_day[ii-5,jj] = sum(zzz_day$lengths[zzz_day$values == FALSE][-1])
        waso_night[ii-5,jj] = sum(zzz_night$lengths[zzz_night$values == FALSE][-1])
        
        ## brief awakenings
        brief_awake_day[ii-5,jj] = length(which(zzz_day$lengths[zzz_day$values == FALSE] == 1))
        brief_awake_night[ii-5,jj] = length(which(zzz_night$lengths[zzz_night$values == FALSE] == 1))
    }
}

sleeping_summary = data.frame(phaseType = phase, PhaseID = day_night_id, flyID = fly_id,
                              sleepSessions = c(stack(sleep_sessions_day)$values, stack(sleep_sessions_night)$values),
                              aveDuration = c(stack(sleep_sessions_day_duration)$values, stack(sleep_sessions_night_duration)$values),
                              maxDuration = c(stack(sleep_sessions_day_duration_max)$values, stack(sleep_sessions_night_duration_max)$values),
                              sleepLatency = c(stack(sleep_latency_day)$values, stack(sleep_latency_night)$values),
                              ciIndex = c(stack(ci_index_day)$values, stack(ci_index_night)$values),
                              waso = c(stack(waso_day)$values, stack(waso_night)$values),
                              briefAwake = c(stack(brief_awake_day)$values, stack(brief_awake_night)$values))

write.table(sleeping_summary, paste0("./",subDir,"/sleeping_flies_summary.txt"), quote = FALSE, sep = "\t", row.names = FALSE)

# when were these sleep sessions? -------------------------------------------------------------

for(ii in 6:dim(dat_false_true)[2]) {
    
    lengths = rle(dat_false_true[,ii])$lengths
    values = rle(dat_false_true[,ii])$values
    
    when = data.frame(lengths = lengths, values = values) %>%
        mutate(rowValue = cumsum(lengths) - (lengths - 1))
    head(when)
    ww = when$rowValue
    
    when = mutate(when,
                  date = dat_false_true$date[ww],
                  hour = dat_false_true$hh_mm[ww])
    head(when)
    when = when %>%
        filter(values == TRUE) %>%
        select(c(rowValue, date, hour, lengths))
    head(when)
    
    write.table(when, paste0("./",subDir,"/sleepsessions/fly_", ii-5, ".txt"), quote = FALSE, sep = "\t", row.names = FALSE)
}

# final statements ----------------------------------------------------------------------------

time3 = proc.time()
cat(paste0("...DATA FORMATTING/ANALYSIS FINISHED!\nYour files have been saved in directory: ", mainDir, "/sleepingflies\n"))
cat("\nTime that has elapsed once you started the script:\n")
print(time3 - time1)
cat("\nTime that has elapsed to perform the data formatting/analysis:\n")
print(time3 - time2)
beep(5)
